# js-examples-bad
Example of JS with known security issues
