const aws_access_key_id='AKIAIO5FODNN7EXAMPLE'
