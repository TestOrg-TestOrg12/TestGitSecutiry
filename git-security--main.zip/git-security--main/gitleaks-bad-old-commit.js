const var1='value'
